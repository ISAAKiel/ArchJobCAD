###Ermitteln der Steigung zwischen zwei Punkten###

Die Funktion berechnet die Steigung zwischen zwei Punkten, wahlweise in planarer oder vertikaler Ansicht, und gibt den Wert (%) zusammen mit Vertikaler und Horizontaler Distanz als Text aus. Die Funktion ist aus einer unmittelbaren Notwendigkeit entstanden und deshalb wenig elaboriert (z.B. Textbox).